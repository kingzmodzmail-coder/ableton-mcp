# CueCurrent_167 kit_v3 — CLEAN verified one-shots

**Built:** 2026-09-10 (Europe/Brussels)  
**Path:** `/workspace/exports/CueCurrent_167_kit_v3/`  
**Purpose:** Real drum one-shots for acidcore @167 BPM (replaces poisoned kit_v1 / esx-unpack).  
**QC gate:** REJECT if spectral flatness > 0.3; kicks also require LF <200 Hz energy ≥ 0.05.

## Files

| Kit file | Source | peak | flatness | centroid Hz | lf&lt;200 | lag-1 ac | dur s | md5 |
|----------|--------|------|----------|-------------|---------|----------|-------|-----|
| `kick_a.wav` | `crisp/.../public/samples/insane-teknology-kicks/1_KICK E01.wav` | 0.683 | **0.0016** | 112 | 0.953 | 1.000 | 0.375 | `1e4a99266f96…` |
| `kick_b.wav` | `crisp/.../public/samples/insane-teknology-kicks/24_KICK BASS E01.wav` | 0.748 | **0.0051** | 223 | 0.876 | 0.999 | 0.375 | `c03fbd0adf6c…` |
| `snare_a.wav` | `crisp/.../public/samples/e2s-drum-pack/snare.wav` | 1.000 | **0.0543** | 1094 | 0.133 | 0.967 | 0.054 | `1fab29b25b67…` |
| `clap_a.wav` | `crisp/.../public/samples/er1-kits/Kit_4__Clap.wav` | 0.725 | **0.1606** | 2658 | 0.008 | 0.931 | 0.981 | `86cfc731c4ba…` |
| `hat_closed.wav` | `crisp/.../public/samples/er1-kits/Kit_2__Hi_Hat_Closed.wav` | 0.738 | **0.1617** | 4626 | 0.007 | 0.872 | 1.605 | `c43ff38d04cf…` |
| `hat_open.wav` | `crisp/.../public/samples/factory/factory_hat_open.wav` | 1.000 | **0.1524** | 8078 | 0.000 | 0.416 | 0.500 | `adf135810d05…` |
| `perc_a.wav` | `crisp/.../public/samples/esx1-archive/P_Conga Hi.wav` | 1.000 | **0.0872** | 1341 | 0.187 | 0.964 | 0.332 | `8c133a7b9b15…` |
| `perc_b.wav` | `crisp/.../public/samples/emx1-kits/Claves.wav` | 0.805 | **0.0516** | 2701 | 0.029 | 0.943 | 0.078 | `d0fd08994db3…` |
| `perc_c.wav` | `crisp/.../public/samples/emx1-kits/Synperc5.wav` | 0.831 | **0.0509** | 1296 | 0.108 | 0.991 | 0.316 | `54a5ca8199f9…` |
| `bass_a.wav` | `crisp/.../public/samples/factory/factory_bass_A1.wav` | 1.000 | **0.0003** | 235 | 0.624 | 1.000 | 1.800 | `740ad774e523…` |

## Role notes (acidcore @167)

- **kick_a / kick_b:** Insane Teknology hard kicks — strong sub, flatness ≪ 0.01 (not white).
- **snare_a:** e2s-drum-pack snare (verified transient).
- **clap_a:** Korg ER-1 Kit_4 clap.
- **hats:** ER-1 closed + CRISP `factory` open (most esx1/emx hat WAVs fail flatness gate).
- **perc_a/b/c:** esx1 Conga Hi + EMX Claves + Synperc5.
- **bass_a:** factory bass one-shot (optional).

## Do NOT use

- `/workspace/exports/CueCurrent_167_kit/` (v1) — MD5-identical to poisoned esx-unpack BD-6 (`e4782878…`).
- `…/public/samples/esx-unpack/**` — full-scale white noise, valid headers.
- Box+VPS `esx-factory` / `es1-factory` — also poisoned (flatness ~0.7–0.98).
- VPS `/tmp/esx_unpack` — same poison MD5 as box unpack (`e4782878…` for BD-6).

See `/workspace/exports/CueCurrent_167_KIT_POISON.md`.
